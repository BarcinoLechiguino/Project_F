<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.4" name="isometric_meta_tiles_alpha_75" tilewidth="64" tileheight="32" tilecount="2" columns="2">
 <image source="isometric_meta_tiles_alpha_75.png" width="128" height="32"/>
</tileset>
